import{i as e,n as t,r as n,t as r}from"./jsx-runtime-Cd5gl7hL.js";import{n as i}from"./settings-Btia4n2s.js";var a=t(),o=e(n(),1),s=r(),c=(0,o.createContext)(null);function l({initialSettings:e,children:t}){let[n,r]=(0,o.useState)(e);return(0,s.jsx)(c.Provider,{value:{settings:n,updateSettings:r},children:t})}function u(){let e=(0,o.useContext)(c);if(!e)throw Error(`useSettings must be used inside SettingsProvider`);return e.settings}function d(){let e=(0,o.useContext)(c);if(!e)throw Error(`useUpdateSettings must be used inside SettingsProvider`);return e.updateSettings}function f(){try{return!!chrome.runtime?.id}catch{return!1}}async function p(e){if(f())try{return await chrome.runtime.sendMessage(e)}catch(e){console.warn(`[API Debugger] sendRuntimeMessage failed:`,e)}}function m(e){return typeof e==`object`&&!!e&&`type`in e&&e.type===`REQUEST_COMPLETE`&&`payload`in e}function h(e){return typeof e==`object`&&!!e&&`type`in e&&e.type===`REQUEST_UPDATED`&&`payload`in e}var g=`
  :host {
    color-scheme: dark;
    --api-color-primary: #8069bf;
    --api-color-primary-soft: #cbb8ff;
    --api-color-primary-strong: #3a1670;
    --api-color-secondary: #7c7296;
    --api-color-secondary-soft: #d9d0ef;
    --api-color-tertiary: #c9a74d;
    --api-color-tertiary-soft: #ffe6a2;
    --api-color-neutral: #79767d;
    --api-bg: #121015;
    --api-surface: #1e1b22;
    --api-surface-raised: #292630;
    --api-border: #403a49;
    --api-border-strong: #5d536b;
    --api-text: #eee8f5;
    --api-text-muted: #9c96a6;
    --api-text-subtle: #79737f;
    --api-danger: #ff8f8f;
    --api-danger-bg: #3f1518;
    --api-success: #8fe6bc;
    --api-warning: #ffd36f;
  }

  @keyframes apidbg-pulse-glow {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.7; transform: scale(1.15); }
  }

  @keyframes apidbg-spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }

  @keyframes apidbg-slide-in-up {
    from { transform: translateY(8px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
  }

  @keyframes apidbg-sweep {
    0% { top: 0; opacity: 0.3; }
    100% { top: 100%; opacity: 0; }
  }

  @keyframes apidbg-pulse-soft {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.55; }
  }

  @keyframes apidbg-wave-pulse {
    0%, 100% { opacity: 0.4; }
    50% { opacity: 1; }
  }

  .apidbg-overlay,
  .apidbg-minimised {
    box-sizing: border-box;
    font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    font-size: 12px;
    line-height: 1.4;
  }

  .apidbg-overlay *,
  .apidbg-minimised * {
    box-sizing: border-box;
  }

  .apidbg-overlay button,
  .apidbg-overlay input,
  .apidbg-minimised button {
    font: inherit;
  }

  .apidbg-overlay {
    position: fixed;
    z-index: 2147483647;
    display: flex;
    width: 380px;
    max-height: 60vh;
    overflow: hidden;
    flex-direction: column;
    border: 1px solid var(--api-border);
    border-radius: 8px;
    background: var(--api-bg);
    color: var(--api-text);
    box-shadow: 0 25px 50px rgba(0, 0, 0, 0.58);
  }

  .apidbg-overlay.is-bottom-right,
  .apidbg-minimised.is-bottom-right {
    right: 16px;
    bottom: 16px;
  }

  .apidbg-overlay.is-bottom-left,
  .apidbg-minimised.is-bottom-left {
    left: 16px;
    bottom: 16px;
  }

  .apidbg-overlay.is-top-right,
  .apidbg-minimised.is-top-right {
    top: 16px;
    right: 16px;
  }

  .apidbg-overlay.is-top-left,
  .apidbg-minimised.is-top-left {
    top: 16px;
    left: 16px;
  }

  .apidbg-header {
    flex-shrink: 0;
    border-bottom: 1px solid var(--api-border);
    background: var(--api-bg);
    padding: 10px 14px;
  }

  .apidbg-title-row,
  .apidbg-title,
  .apidbg-actions,
  .apidbg-chip-row,
  .apidbg-paused,
  .apidbg-row,
  .apidbg-row-tools,
  .apidbg-tabs,
  .apidbg-detail-actions,
  .apidbg-ai-title,
  .apidbg-ai-footer,
  .apidbg-minimised {
    display: flex;
    align-items: center;
  }

  .apidbg-title-row {
    justify-content: space-between;
    gap: 12px;
  }

  .apidbg-title {
    gap: 8px;
    min-width: 0;
    font-size: 13px;
    font-weight: 750;
  }

  .apidbg-actions {
    gap: 4px;
  }

  .apidbg-icon-button {
    display: inline-flex;
    width: 22px;
    height: 22px;
    align-items: center;
    justify-content: center;
    border: 0;
    border-radius: 5px;
    background: none;
    color: var(--api-text-subtle);
    cursor: pointer;
    line-height: 1;
    padding: 0;
    transition: background 0.15s ease, color 0.15s ease;
  }

  .apidbg-icon-button:hover,
  .apidbg-icon-button:focus-visible {
    background: var(--api-surface-raised);
    color: var(--api-color-primary-soft);
    outline: none;
  }

  .apidbg-icon-button svg {
    width: 14px;
    height: 14px;
    flex-shrink: 0;
    stroke: currentColor;
  }

  .apidbg-chip-row {
    gap: 6px;
    margin-top: 8px;
    flex-wrap: wrap;
  }

  .apidbg-chip {
    border-radius: 99px;
    background: var(--api-surface-raised);
    color: var(--chip-color, var(--api-text-muted));
    font-size: 11px;
    padding: 3px 10px;
  }

  .apidbg-sparkline {
    position: relative;
    padding: 0 12px 4px;
  }

  .apidbg-sparkline canvas {
    display: block;
    width: 100%;
    height: 36px;
  }

  .apidbg-tooltip {
    position: fixed;
    z-index: 2147483647;
    pointer-events: none;
    border: 1px solid var(--api-border);
    border-radius: 6px;
    background: var(--api-surface-raised);
    color: var(--api-text);
    font-size: 11px;
    padding: 4px 8px;
    max-width: 260px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .apidbg-paused {
    justify-content: center;
    gap: 12px;
    background: rgba(201, 167, 77, 0.18);
    color: var(--api-warning);
    font-size: 12px;
    padding: 6px;
    text-align: center;
  }

  .apidbg-link-button {
    border: 0;
    background: none;
    color: inherit;
    cursor: pointer;
    font-size: 12px;
    padding: 0;
    text-decoration: underline;
  }

  .apidbg-list {
    position: relative;
    flex: 1;
    overflow-y: auto;
    transition: opacity 0.2s;
  }

  .apidbg-list.is-paused {
    opacity: 0.5;
  }

  .apidbg-sweep {
    position: absolute;
    left: 0;
    right: 0;
    z-index: 2;
    height: 1px;
    background: rgba(238, 232, 245, 0.35);
    animation: apidbg-sweep 0.3s linear forwards;
  }

  .apidbg-row-wrap {
    border-bottom: 1px solid rgba(64, 58, 73, 0.7);
  }

  .apidbg-row-wrap.has-duplicates {
    border-left: 3px solid rgba(201, 167, 77, 0.7);
  }

  .apidbg-row {
    gap: 8px;
    height: 40px;
    padding: 0 12px;
    background: var(--api-bg);
    cursor: pointer;
    transition: background 0.1s;
  }

  .apidbg-row:hover {
    background: var(--api-surface);
  }

  .apidbg-row:focus-visible,
  .apidbg-tab:focus-visible,
  .apidbg-search:focus-visible,
  .apidbg-plain-button:focus-visible,
  .apidbg-primary-button:focus-visible,
  .apidbg-secondary-button:focus-visible,
  .apidbg-minimised:focus-visible,
  .apidbg-link-button:focus-visible,
  .apidbg-json-row:focus-visible,
  .apidbg-json-copy:focus-visible {
    outline: 2px solid var(--api-color-primary-soft);
    outline-offset: 2px;
  }

  .apidbg-path {
    flex: 1;
    min-width: 0;
    overflow: hidden;
    color: var(--api-text-muted);
    font-size: 11px;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .apidbg-chevron {
    color: var(--api-text-subtle);
    font-size: 14px;
    transition: transform 0.15s ease;
  }

  .apidbg-chevron.is-open {
    transform: rotate(180deg);
  }

  .apidbg-detail {
    border-top: 1px solid var(--api-border);
    background: var(--api-bg);
    padding: 12px;
  }

  .apidbg-detail-header {
    display: flex;
    justify-content: space-between;
    gap: 8px;
    margin-bottom: 8px;
  }

  .apidbg-tabs {
    gap: 12px;
  }

  .apidbg-tab {
    border: 0;
    border-bottom: 2px solid transparent;
    background: none;
    color: var(--api-text-subtle);
    cursor: pointer;
    font-size: 12px;
    padding: 4px 0;
    text-transform: capitalize;
  }

  .apidbg-tab.is-active {
    border-bottom-color: var(--api-color-primary-soft);
    color: var(--api-text);
  }

  .apidbg-row-tools {
    gap: 8px;
  }

  .apidbg-search {
    width: 120px;
    border: 1px solid var(--api-border);
    border-radius: 6px;
    background: var(--api-surface);
    color: var(--api-text);
    font-size: 11px;
    outline: none;
    padding: 3px 8px;
  }

  .apidbg-search:focus {
    border-color: var(--api-color-primary-soft);
  }

  .apidbg-plain-button {
    border: 0;
    background: none;
    color: var(--api-text-subtle);
    cursor: pointer;
    font-size: 11px;
    padding: 0;
  }

  .apidbg-plain-button:hover {
    color: var(--api-color-primary-soft);
  }

  .apidbg-json-box {
    max-height: 280px;
    overflow-y: auto;
    border: 1px solid var(--api-border);
    border-radius: 6px 6px 0 0;
    background: #18151d;
    padding: 8px;
  }

  .apidbg-json-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 28px;
    margin-top: -1px;
    border: 1px solid var(--api-border);
    border-top: 0;
    border-radius: 0 0 6px 6px;
    background: var(--api-surface);
    padding: 0 12px;
  }

  .apidbg-json-meta {
    color: var(--api-text-subtle);
    font-size: 11px;
  }

  .apidbg-json-row {
    display: flex;
    min-height: 20px;
    align-items: center;
    gap: 5px;
    border-radius: 4px;
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    font-size: 12px;
  }

  .apidbg-json-row:hover {
    background: rgba(203, 184, 255, 0.06);
  }

  .apidbg-json-key {
    color: var(--api-color-primary-soft);
  }

  .apidbg-json-key.is-match {
    border-radius: 2px;
    background: rgba(201, 167, 77, 0.18);
    color: var(--api-warning);
    padding: 0 2px;
  }

  .apidbg-json-punct,
  .apidbg-json-preview,
  .apidbg-json-path {
    color: var(--api-text-subtle);
  }

  .apidbg-json-path {
    flex: 1;
    min-width: 0;
    overflow: hidden;
    font-size: 10px;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .apidbg-json-value-string {
    color: var(--api-success);
  }

  .apidbg-json-value-number {
    color: #89c2ff;
  }

  .apidbg-json-value-boolean {
    color: var(--api-warning);
  }

  .apidbg-json-value-null,
  .apidbg-json-value-undefined {
    color: var(--api-text-subtle);
    font-style: italic;
  }

  .apidbg-json-copy {
    flex-shrink: 0;
    border: 0;
    border-radius: 4px;
    background: transparent;
    color: var(--api-text-subtle);
    cursor: pointer;
    font-size: 10px;
    line-height: 1;
    opacity: 0;
    padding: 3px 5px;
  }

  .apidbg-json-row:hover .apidbg-json-copy,
  .apidbg-json-copy:focus-visible,
  .apidbg-json-copy.is-copied {
    opacity: 1;
  }

  .apidbg-json-copy:hover,
  .apidbg-json-copy.is-copied {
    background: var(--api-surface-raised);
    color: var(--api-color-primary-soft);
  }

  .apidbg-detail-actions {
    gap: 8px;
    padding-top: 8px;
  }

  .apidbg-meta-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 6px;
    margin-bottom: 8px;
  }

  .apidbg-meta-cell {
    border: 1px solid var(--api-border);
    border-radius: 6px;
    background: var(--api-surface);
    padding: 6px 8px;
  }

  .apidbg-meta-label {
    color: var(--api-text-subtle);
    font-size: 10px;
    text-transform: uppercase;
  }

  .apidbg-meta-value {
    margin-top: 2px;
    color: var(--api-text-muted);
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    font-size: 12px;
    font-weight: 700;
  }

  .apidbg-primary-button,
  .apidbg-secondary-button {
    border-radius: 6px;
    cursor: pointer;
    font-size: 12px;
    padding: 5px 12px;
  }

  .apidbg-primary-button {
    border: 0;
    background: var(--api-color-primary);
    color: var(--api-text);
  }

  .apidbg-secondary-button {
    border: 1px solid var(--api-border);
    background: var(--api-surface);
    color: var(--api-text-muted);
  }

  .apidbg-ai-card {
    margin-top: 8px;
    border-left: 3px solid var(--api-color-primary-soft);
    border-radius: 6px;
    background: var(--api-surface);
    padding: 12px;
    animation: apidbg-slide-in-up 0.2s ease-out;
  }

  .apidbg-ai-title {
    gap: 8px;
  }

  .apidbg-ai-text {
    color: var(--api-text-muted);
    font-size: 13px;
    line-height: 1.6;
    margin-top: 8px;
  }

  .apidbg-ai-pill {
    margin: 0 2px;
    border-radius: 4px;
    background: rgba(201, 167, 77, 0.18);
    color: var(--api-warning);
    font-size: 11px;
    font-weight: 650;
    padding: 1px 6px;
  }

  .apidbg-ai-footer {
    margin-top: 8px;
  }

  .apidbg-footer {
    display: flex;
    justify-content: flex-end;
    flex-shrink: 0;
    border-top: 1px solid var(--api-border);
    background: var(--api-bg);
    padding: 6px 12px;
  }

  .apidbg-minimised {
    position: fixed;
    z-index: 2147483647;
    gap: 6px;
    border: 1px solid var(--api-border);
    border-radius: 99px;
    background: var(--api-surface);
    box-shadow: 0 14px 34px rgba(0, 0, 0, 0.35);
    color: var(--api-text-muted);
    cursor: pointer;
    font-size: 12px;
    font-weight: 700;
    padding: 6px 12px;
  }

  .apidbg-live-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 99px;
    background: var(--api-text-subtle);
  }

  .apidbg-live-dot.is-capturing {
    background: var(--api-success);
    box-shadow: 0 0 8px var(--api-success);
    animation: apidbg-pulse-glow 2s ease-in-out infinite;
  }

  .apidbg-method {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 52px;
    height: 20px;
    border-radius: 4px;
    background: var(--method-bg, var(--api-surface-raised));
    color: var(--method-color, var(--api-color-primary-soft));
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 0.4px;
  }

  .apidbg-status,
  .apidbg-duration {
    color: var(--badge-color, var(--api-text-muted));
    font-size: 11px;
    font-weight: 700;
  }

  .apidbg-duration {
    min-width: 52px;
    text-align: right;
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  }

  .apidbg-timing-chip {
    display: inline-flex;
    min-width: 22px;
    height: 16px;
    align-items: center;
    justify-content: center;
    border: 1px solid var(--chip-border, var(--api-border));
    border-radius: 999px;
    background: var(--chip-bg, var(--api-surface));
    color: var(--chip-color, var(--api-text-subtle));
    font-size: 9px;
    font-weight: 800;
    line-height: 1;
    padding: 0 5px;
  }

  .apidbg-badge {
    border: 1px solid var(--badge-border, var(--api-border));
    border-radius: 3px;
    background: var(--badge-bg, var(--api-surface));
    color: var(--badge-color, var(--api-text-muted));
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 0.4px;
    padding: 1px 6px;
    animation: apidbg-pulse-soft 1.6s ease-in-out infinite;
  }

  .apidbg-spinner {
    display: inline-block;
    animation: apidbg-spin 0.9s linear infinite;
  }

  .apidbg-empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 40px 16px;
    text-align: center;
  }

  .apidbg-wave {
    color: var(--api-border-strong);
    animation: apidbg-wave-pulse 2s ease-in-out infinite;
  }

  .apidbg-scroll::-webkit-scrollbar {
    width: 4px;
    height: 4px;
  }

  .apidbg-scroll::-webkit-scrollbar-track {
    background: transparent;
  }

  .apidbg-scroll::-webkit-scrollbar-thumb {
    background: var(--api-border-strong);
    border-radius: 99px;
  }

  @media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
      animation-duration: 0.001ms !important;
      animation-iteration-count: 1 !important;
      scroll-behavior: auto !important;
      transition-duration: 0.001ms !important;
    }
  }
`;function _({isCapturing:e}){return(0,s.jsx)(`span`,{className:`apidbg-live-dot${e?` is-capturing`:``}`})}function v(){return(0,s.jsx)(`svg`,{viewBox:`0 0 16 16`,fill:`none`,"aria-hidden":`true`,children:(0,s.jsx)(`path`,{d:`M6 4.5v7M10 4.5v7`,strokeWidth:`1.7`,strokeLinecap:`round`})})}function y(){return(0,s.jsx)(`svg`,{viewBox:`0 0 16 16`,fill:`none`,"aria-hidden":`true`,children:(0,s.jsx)(`path`,{d:`M6 4.5l5 3.5-5 3.5v-7z`,strokeWidth:`1.5`,strokeLinejoin:`round`})})}function b(){return(0,s.jsxs)(`svg`,{viewBox:`0 0 16 16`,fill:`none`,"aria-hidden":`true`,children:[(0,s.jsx)(`rect`,{x:`3`,y:`3`,width:`10`,height:`10`,rx:`1.5`,strokeWidth:`1.4`}),(0,s.jsx)(`path`,{d:`M9.5 3v10`,strokeWidth:`1.4`,strokeLinecap:`round`})]})}function x(){return(0,s.jsx)(`svg`,{viewBox:`0 0 16 16`,fill:`none`,"aria-hidden":`true`,children:(0,s.jsx)(`path`,{d:`M4.5 8h7`,strokeWidth:`1.7`,strokeLinecap:`round`})})}function S({method:e}){let t={GET:{bg:`rgba(203, 184, 255, 0.18)`,color:`var(--api-color-primary-soft)`},POST:{bg:`rgba(143, 230, 188, 0.14)`,color:`var(--api-success)`},PUT:{bg:`rgba(201, 167, 77, 0.2)`,color:`var(--api-warning)`},PATCH:{bg:`rgba(128, 105, 191, 0.26)`,color:`var(--api-color-secondary-soft)`},DELETE:{bg:`rgba(255, 143, 143, 0.15)`,color:`var(--api-danger)`}},n=t[e.toUpperCase()]??t.GET;return(0,s.jsx)(`span`,{className:`apidbg-method`,style:{"--method-bg":n.bg,"--method-color":n.color},children:e.toUpperCase()})}function C({status:e}){return(0,s.jsx)(`span`,{className:`apidbg-status`,style:{"--badge-color":e>=500?`var(--api-danger)`:e>=400?`var(--api-warning)`:e>=200&&e<300?`var(--api-success)`:`var(--api-text-muted)`},children:e||`-`})}function w({ms:e}){let t=e>=1500?`var(--api-danger)`:e>=500?`var(--api-warning)`:`var(--api-success)`,n=e>999?`${(e/1e3).toFixed(1)}s`:`${Math.round(e)}ms`;return(0,s.jsx)(`span`,{className:`apidbg-duration`,style:{"--badge-color":t},children:n})}function T({source:e}){return(0,s.jsx)(`span`,{className:`apidbg-badge`,style:e===`cdp`?{"--badge-bg":`rgba(98, 214, 157, 0.14)`,"--badge-border":`rgba(98, 214, 157, 0.4)`,"--badge-color":`#8fe6bc`}:e===`performance`?{"--badge-bg":`rgba(77, 163, 255, 0.14)`,"--badge-border":`rgba(77, 163, 255, 0.4)`,"--badge-color":`#89c2ff`}:{"--badge-bg":`rgba(201, 167, 77, 0.16)`,"--badge-border":`rgba(201, 167, 77, 0.38)`,"--badge-color":`var(--api-warning)`},children:e===`cdp`?`CDP`:e===`performance`?`Browser`:`Proxy`})}function E({source:e}){return(0,s.jsx)(`span`,{className:`apidbg-timing-chip`,style:e===`cdp`?{"--chip-bg":`rgba(98, 214, 157, 0.14)`,"--chip-border":`rgba(98, 214, 157, 0.4)`,"--chip-color":`#8fe6bc`}:e===`performance`?{"--chip-bg":`rgba(77, 163, 255, 0.14)`,"--chip-border":`rgba(77, 163, 255, 0.4)`,"--chip-color":`#89c2ff`}:{"--chip-bg":`rgba(201, 167, 77, 0.16)`,"--chip-border":`rgba(201, 167, 77, 0.38)`,"--chip-color":`var(--api-warning)`},title:e===`cdp`?`Chrome DevTools Protocol timing`:e===`performance`?`Browser timing`:`JavaScript proxy timing`,children:e===`cdp`?`CDP`:e===`performance`?`BR`:`JS`})}function D({count:e}){return(0,s.jsxs)(`span`,{className:`apidbg-badge`,style:{"--badge-bg":`rgba(201, 167, 77, 0.18)`,"--badge-border":`rgba(201, 167, 77, 0.45)`,"--badge-color":`var(--api-warning)`},title:`${e} matching requests in this session`,children:[`DUP x`,e]})}function O(){return(0,s.jsx)(`span`,{className:`apidbg-badge`,style:{"--badge-bg":`var(--api-danger-bg)`,"--badge-border":`rgba(255, 143, 143, 0.45)`,"--badge-color":`var(--api-danger)`},children:`SLOW`})}function k({size:e}){return(0,s.jsx)(`span`,{className:`apidbg-badge`,style:{"--badge-bg":`rgba(201, 167, 77, 0.18)`,"--badge-border":`rgba(201, 167, 77, 0.45)`,"--badge-color":`var(--api-warning)`},title:`Large response payload: ${z(e)}`,children:`LARGE`})}function A({size:e=16}){return(0,s.jsxs)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,fill:`none`,className:`apidbg-spinner`,children:[(0,s.jsx)(`circle`,{cx:`12`,cy:`12`,r:`9`,stroke:`var(--api-color-primary-soft)`,strokeWidth:`2.5`,strokeOpacity:`0.25`}),(0,s.jsx)(`path`,{d:`M21 12a9 9 0 0 0-9-9`,stroke:`var(--api-color-primary-soft)`,strokeWidth:`2.5`,strokeLinecap:`round`})]})}function j({label:e,color:t}){return(0,s.jsx)(`span`,{className:`apidbg-chip`,style:{"--chip-color":t},children:e})}function M(e){return e.replace(/\\/g,`\\\\`).replace(/"/g,`\\"`)}function N(e,t,n){return n?`${e}[${t}]`:/^[A-Za-z_$][\w$]*$/.test(t)?`${e}.${t}`:`${e}["${M(t)}"]`}function P(e){return typeof e==`string`?JSON.stringify(e):typeof e==`number`||typeof e==`boolean`?String(e):e===null?`null`:e===void 0?`undefined`:JSON.stringify(e,null,2)}function F({path:e}){let[t,n]=(0,o.useState)(!1);return(0,s.jsx)(`button`,{className:`apidbg-json-copy${t?` is-copied`:``}`,title:`Copy path: ${e}`,"aria-label":`Copy JSON path ${e}`,onClick:t=>{t.stopPropagation(),navigator.clipboard?.writeText(e),n(!0),window.setTimeout(()=>n(!1),1200)},children:t?`Copied`:`Path`})}function I({k:e,value:t,depth:n,search:r,forceExpand:i,path:a}){let[c,l]=(0,o.useState)(n<2),u=i===`all`?!0:i===`none`?!1:c,d=t&&typeof t==`object`&&!Array.isArray(t),f=Array.isArray(t),p=P(t),m=r.trim().toLowerCase(),h=!!(m&&(e?.toLowerCase().includes(m)||a.toLowerCase().includes(m)||typeof p==`string`&&p.toLowerCase().includes(m))),g=m&&!h?.35:1,_=n*16;if(d||f){let o=t,c=f?o.map((e,t)=>[String(t),e]):Object.entries(o),d=c.length;return(0,s.jsxs)(`div`,{style:{opacity:g,paddingLeft:n===0?0:12,borderLeft:n===0?`none`:`1px solid var(--api-border)`},children:[(0,s.jsxs)(`div`,{className:`apidbg-json-row`,role:`treeitem`,tabIndex:0,"aria-expanded":u,"aria-label":`${a}, ${f?`array`:`object`}, ${d} ${f?`items`:`keys`}`,onClick:()=>l(e=>!e),onKeyDown:e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),l(e=>!e)),e.key===`ArrowRight`&&!u&&(e.preventDefault(),l(!0)),e.key===`ArrowLeft`&&u&&(e.preventDefault(),l(!1))},style:{cursor:`pointer`,paddingLeft:_},children:[(0,s.jsx)(`span`,{style:{display:`inline-block`,width:10,color:`var(--api-text-subtle)`,transform:u?`rotate(90deg)`:`rotate(0deg)`,transition:`transform 0.15s`,fontSize:10},children:`>`}),e!==void 0&&(0,s.jsxs)(`span`,{className:`apidbg-json-key${h?` is-match`:``}`,children:[`"`,e,`"`]}),e!==void 0&&(0,s.jsx)(`span`,{className:`apidbg-json-punct`,children:`:`}),!u&&(0,s.jsx)(`span`,{className:`apidbg-json-preview`,children:f?`[...] ${d} items`:`{...} ${d} keys`}),u&&(0,s.jsx)(`span`,{className:`apidbg-json-punct`,children:f?`[`:`{`}),(0,s.jsx)(`span`,{className:`apidbg-json-path`,title:a,children:a}),(0,s.jsx)(F,{path:a})]}),u&&(0,s.jsxs)(`div`,{role:`group`,children:[c.map(([e,t])=>(0,s.jsx)(I,{k:e,value:t,depth:n+1,search:r,forceExpand:i,path:N(a,e,f)},e)),(0,s.jsx)(`div`,{style:{paddingLeft:_+14,color:`var(--api-text-subtle)`,fontSize:12,fontFamily:`ui-monospace, monospace`},children:f?`]`:`}`})]})]})}let v=t===null?`null`:typeof t,y=`apidbg-json-value-${v}`;return(0,s.jsxs)(`div`,{className:`apidbg-json-row`,role:`treeitem`,tabIndex:0,"aria-label":`${a}, ${v}, ${p}`,style:{opacity:g,paddingLeft:_+14},children:[e!==void 0&&(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(`span`,{className:`apidbg-json-key${h?` is-match`:``}`,children:[`"`,e,`"`]}),(0,s.jsx)(`span`,{className:`apidbg-json-punct`,children:`:`})]}),(0,s.jsx)(`span`,{className:y,children:p}),(0,s.jsx)(`span`,{className:`apidbg-json-path`,title:a,children:a}),(0,s.jsx)(F,{path:a})]})}function L(e){return!e||typeof e!=`object`?0:Array.isArray(e)?e.reduce((e,t)=>e+L(t),0):Object.keys(e).length+Object.values(e).reduce((e,t)=>e+L(t),0)}function R(e){if(!e)return null;try{return JSON.parse(e)}catch{return{body:e}}}function z(e){return e<1024?`${e} B`:`${(e/1024).toFixed(1)} KB`}function B(e){try{let t=new URL(e);return t.pathname+t.search}catch{return e}}function V({requests:e}){let t=(0,o.useRef)(null),[n,r]=(0,o.useState)(null);return(0,o.useEffect)(()=>{let n=t.current;if(!n)return;let r=window.devicePixelRatio||1,i=n.clientWidth,a=n.clientHeight;n.width=i*r,n.height=a*r;let o=n.getContext(`2d`);if(!o||(o.scale(r,r),o.clearRect(0,0,i,a),e.length<2))return;let s=getComputedStyle(n),c=s.getPropertyValue(`--api-color-primary-soft`).trim()||`#cbb8ff`,l=s.getPropertyValue(`--api-danger`).trim()||`#ff8f8f`,u=Math.max(...e.map(e=>e.duration),100),d=e.map((t,n)=>({x:n/(e.length-1)*(i-8)+4,y:a-6-t.duration/u*(a-12),r:t}));o.strokeStyle=c,o.lineWidth=1.2,o.beginPath(),d.forEach((e,t)=>t===0?o.moveTo(e.x,e.y):o.lineTo(e.x,e.y)),o.stroke(),d.forEach(e=>{o.beginPath(),o.arc(e.x,e.y,2.5,0,Math.PI*2),o.fillStyle=e.r.isSlow?l:c,o.fill()})},[e]),(0,s.jsxs)(`div`,{className:`apidbg-sparkline`,children:[(0,s.jsx)(`canvas`,{ref:t,onMouseMove:t=>{let n=t.currentTarget.getBoundingClientRect(),i=t.clientX-n.left,a=e[Math.round(i/n.width*(e.length-1))];a&&r({x:t.clientX,y:t.clientY,r:a})},onMouseLeave:()=>r(null)}),n&&(0,s.jsxs)(`div`,{className:`apidbg-tooltip`,style:{top:n.y-36,left:n.x+8},children:[B(n.r.url),` - `,Math.round(n.r.duration),`ms`]})]})}function H({state:e,text:t,error:n,url:r,onDismiss:i}){if(e===`idle`)return null;if(e===`loading`)return(0,s.jsxs)(`div`,{className:`apidbg-ai-card`,children:[(0,s.jsxs)(`div`,{className:`apidbg-ai-title`,children:[(0,s.jsx)(A,{}),(0,s.jsx)(`span`,{style:{color:`var(--api-text-muted)`,fontSize:13},children:`Analysing request...`})]}),(0,s.jsx)(`div`,{style:{height:10,width:`90%`,borderRadius:4,marginTop:10,background:`var(--api-surface-raised)`}}),(0,s.jsx)(`div`,{style:{height:10,width:`72%`,borderRadius:4,marginTop:6,background:`var(--api-surface-raised)`}})]});if(e===`error`)return(0,s.jsxs)(`div`,{className:`apidbg-ai-card`,children:[(0,s.jsxs)(`div`,{className:`apidbg-ai-title`,children:[(0,s.jsx)(`span`,{style:{color:`var(--api-danger)`,fontSize:14},children:`!`}),(0,s.jsx)(`span`,{style:{color:`var(--api-text)`,fontSize:13,fontWeight:700},children:`AI Diagnosis`}),(0,s.jsx)(`span`,{title:r,style:{marginLeft:`auto`,color:`var(--api-text-subtle)`,fontSize:11,maxWidth:140,overflow:`hidden`,textOverflow:`ellipsis`,whiteSpace:`nowrap`},children:r})]}),(0,s.jsx)(`div`,{className:`apidbg-ai-text`,children:n??`Unknown error. Check your API key.`}),(0,s.jsx)(`div`,{className:`apidbg-ai-footer`,children:(0,s.jsx)(`button`,{className:`apidbg-plain-button`,onClick:i,style:{marginLeft:`auto`},children:`Dismiss`})})]});let a=[`N+1`,`over-fetching`,`waterfall`,`pagination`],o=[t??`This endpoint may benefit from checking repeated calls, payload size, and response latency.`];return a.forEach(e=>{o=o.flatMap(t=>typeof t==`string`?t.split(RegExp(`(${e})`,`i`)).map((t,n)=>t.toLowerCase()===e.toLowerCase()?(0,s.jsx)(`span`,{className:`apidbg-ai-pill`,children:t},`${e}-${n}`):t):[t])}),(0,s.jsxs)(`div`,{className:`apidbg-ai-card`,children:[(0,s.jsxs)(`div`,{className:`apidbg-ai-title`,children:[(0,s.jsx)(`span`,{style:{color:`var(--api-color-primary-soft)`,fontSize:14},children:`*`}),(0,s.jsx)(`span`,{style:{color:`var(--api-text)`,fontSize:13,fontWeight:700},children:`AI Diagnosis`}),(0,s.jsx)(`span`,{title:r,style:{marginLeft:`auto`,color:`var(--api-text-subtle)`,fontSize:11,maxWidth:140,overflow:`hidden`,textOverflow:`ellipsis`,whiteSpace:`nowrap`},children:r})]}),(0,s.jsx)(`div`,{className:`apidbg-ai-text`,children:o}),(0,s.jsxs)(`div`,{className:`apidbg-ai-footer`,children:[(0,s.jsx)(`span`,{style:{color:`var(--api-text-subtle)`,fontSize:11},children:`Generated just now`}),(0,s.jsx)(`button`,{className:`apidbg-plain-button`,onClick:i,style:{marginLeft:`auto`},children:`Dismiss`})]})]})}function U({req:e}){let t=u(),[n,r]=(0,o.useState)(!1),[i,a]=(0,o.useState)(`response`),[c,l]=(0,o.useState)(``),[d,f]=(0,o.useState)(null),[m,h]=(0,o.useState)(`idle`),[g,_]=(0,o.useState)(``),[v,y]=(0,o.useState)(``),[b,x]=(0,o.useState)(!1),A=(0,o.useMemo)(()=>B(e.url),[e.url]),j=(0,o.useMemo)(()=>R(e.responseBody),[e.responseBody]),M=(0,o.useMemo)(()=>({method:e.method,url:e.url,headers:e.requestHeaders,body:e.requestBody,requestSize:e.requestSize,fingerprint:e.fingerprint,duplicateOf:e.duplicateOf,duplicateCount:e.duplicateCount}),[e]),N=i===`response`?j??{body:null}:M,P=e.responseSize>t.largePayloadThresholdKb*1024;return(0,s.jsxs)(`div`,{className:`apidbg-row-wrap${e.duplicateCount>1?` has-duplicates`:``}`,children:[(0,s.jsxs)(`div`,{className:`apidbg-row`,role:`button`,tabIndex:0,"aria-expanded":n,"aria-label":`${e.method} ${A}, status ${e.status||`unknown`}, ${Math.round(e.duration)} milliseconds`,onClick:()=>r(e=>!e),onKeyDown:e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),r(e=>!e))},children:[(0,s.jsx)(S,{method:e.method}),(0,s.jsx)(`span`,{className:`apidbg-path`,title:e.url,children:A}),(0,s.jsx)(C,{status:e.status}),(0,s.jsx)(E,{source:e.timingSource}),(0,s.jsx)(w,{ms:e.duration}),e.duplicateCount>1&&(0,s.jsx)(D,{count:e.duplicateCount}),e.isSlow&&(0,s.jsx)(O,{}),P&&(0,s.jsx)(k,{size:e.responseSize}),(0,s.jsx)(`svg`,{className:`apidbg-chevron${n?` is-open`:``}`,width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,"aria-hidden":`true`,children:(0,s.jsx)(`path`,{d:`M2 4L6 8L10 4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})})]}),n&&(0,s.jsxs)(`div`,{className:`apidbg-detail`,children:[(0,s.jsxs)(`div`,{className:`apidbg-detail-header`,children:[(0,s.jsx)(`div`,{className:`apidbg-tabs`,children:[`response`,`request`].map(e=>(0,s.jsx)(`button`,{className:`apidbg-tab${i===e?` is-active`:``}`,onClick:()=>a(e),children:e},e))}),(0,s.jsxs)(`div`,{className:`apidbg-row-tools`,children:[(0,s.jsx)(`input`,{className:`apidbg-search`,value:c,onChange:e=>l(e.target.value),placeholder:`Search keys...`}),(0,s.jsx)(`button`,{className:`apidbg-plain-button`,onClick:()=>f(d===`all`?`none`:`all`),children:d===`all`?`Collapse all`:`Expand all`})]})]}),(0,s.jsxs)(`div`,{className:`apidbg-meta-grid`,children:[(0,s.jsxs)(`div`,{className:`apidbg-meta-cell`,children:[(0,s.jsx)(`div`,{className:`apidbg-meta-label`,children:`TTFB`}),(0,s.jsx)(`div`,{className:`apidbg-meta-value`,children:e.ttfb>0?`${e.ttfb}ms`:`-`})]}),(0,s.jsxs)(`div`,{className:`apidbg-meta-cell`,children:[(0,s.jsx)(`div`,{className:`apidbg-meta-label`,children:`Request`}),(0,s.jsx)(`div`,{className:`apidbg-meta-value`,children:z(e.requestSize)})]}),(0,s.jsxs)(`div`,{className:`apidbg-meta-cell`,children:[(0,s.jsx)(`div`,{className:`apidbg-meta-label`,children:`Response`}),(0,s.jsx)(`div`,{className:`apidbg-meta-value`,children:z(e.responseSize)})]}),P&&(0,s.jsxs)(`div`,{className:`apidbg-meta-cell`,children:[(0,s.jsx)(`div`,{className:`apidbg-meta-label`,children:`Payload Limit`}),(0,s.jsx)(`div`,{className:`apidbg-meta-value`,children:z(t.largePayloadThresholdKb*1024)})]}),(0,s.jsxs)(`div`,{className:`apidbg-meta-cell`,children:[(0,s.jsx)(`div`,{className:`apidbg-meta-label`,children:`Timing`}),(0,s.jsx)(`div`,{className:`apidbg-meta-value`,children:e.timingSource===`cdp`?`CDP`:e.timingSource===`performance`?`Browser`:`Proxy`})]}),e.duplicateCount>1&&(0,s.jsxs)(`div`,{className:`apidbg-meta-cell`,children:[(0,s.jsx)(`div`,{className:`apidbg-meta-label`,children:`Duplicate Group`}),(0,s.jsxs)(`div`,{className:`apidbg-meta-value`,children:[e.duplicateCount,` calls`]})]})]}),(0,s.jsx)(`div`,{className:`apidbg-json-box apidbg-scroll`,role:`tree`,"aria-label":`${i===`response`?`Response`:`Request`} JSON tree`,children:(0,s.jsx)(I,{value:N,depth:0,search:c,forceExpand:d,path:i})}),(0,s.jsxs)(`div`,{className:`apidbg-json-footer`,children:[(0,s.jsxs)(`span`,{className:`apidbg-json-meta`,children:[(e.responseSize/1024).toFixed(1),` KB response - `,L(N),` keys`]}),(0,s.jsx)(`button`,{className:`apidbg-plain-button`,onClick:()=>{navigator.clipboard?.writeText(e.responseBody??JSON.stringify(N,null,2)),x(!0),window.setTimeout(()=>x(!1),1500)},style:{color:b?`var(--api-success)`:`var(--api-color-primary-soft)`},children:b?`Copied`:`Copy JSON`})]}),(0,s.jsxs)(`div`,{className:`apidbg-detail-actions`,children:[(0,s.jsx)(T,{source:e.timingSource}),(e.isSlow||e.status>=400)&&(0,s.jsx)(`button`,{className:`apidbg-primary-button`,onClick:async()=>{h(`loading`),y(``);try{let t=await p({type:`ASK_AI_SUGGESTION`,payload:{id:e.id,method:e.method,url:e.url,status:e.status,duration:e.duration,ttfb:e.ttfb,responseSize:e.responseSize,isSlow:e.isSlow,isDuplicate:e.isDuplicate,duplicateCount:e.duplicateCount,dependsOnCount:e.dependsOn.length}});if(!t?.ok)throw Error(t?.error??`Unable to ask AI. Check the extension service worker.`);_(t.suggestion??`No suggestion returned.`),h(`result`)}catch(e){h(`error`),y(e instanceof Error?e.message:`Unknown error. Check your API key.`)}},children:`Ask AI`}),(0,s.jsx)(`button`,{className:`apidbg-secondary-button`,onClick:()=>{p({type:`SELECT_REPLAY`,payload:{id:e.id,method:e.method,url:e.url,headers:e.requestHeaders,body:e.requestBody,originalResponseBody:e.responseBody}})},children:`Replay`})]}),(0,s.jsx)(H,{state:m,url:A,text:g||e.aiSuggestion||`No suggestion returned.`,error:v,onDismiss:()=>h(`idle`)})]})]})}function W(){return(0,s.jsxs)(`div`,{className:`apidbg-empty`,children:[(0,s.jsxs)(`svg`,{width:`40`,height:`40`,viewBox:`0 0 40 40`,className:`apidbg-wave`,children:[(0,s.jsx)(`path`,{d:`M2 20 Q 10 8 18 20 T 34 20`,stroke:`currentColor`,strokeWidth:`2`,fill:`none`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M2 26 Q 10 14 18 26 T 34 26`,stroke:`currentColor`,strokeWidth:`2`,fill:`none`,strokeLinecap:`round`,opacity:`0.5`})]}),(0,s.jsx)(`div`,{style:{color:`var(--api-text-subtle)`,fontSize:13,fontWeight:600},children:`Waiting for requests`}),(0,s.jsx)(`div`,{style:{color:`var(--api-border-strong)`,fontSize:12},children:`Navigate or interact with the page`})]})}function G(e){return`is-${e.toLowerCase().replaceAll(` `,`-`)}`}function K(){let e=u(),[t,n]=(0,o.useState)([]),[r,i]=(0,o.useState)(e.showOverlayOnLoad?`feed`:`minimised`),[a,c]=(0,o.useState)(!1);(0,o.useEffect)(()=>{let e=(e,t)=>{let n=e.findIndex(e=>e.id===t.id);if(n===-1)return[t,...e].slice(0,100);let r=[...e];return r[n]=t,r},t=t=>{m(t)&&n(n=>e(n,t.payload)),h(t)&&n(n=>e(n,t.payload))};try{return chrome.runtime?.id?(chrome.runtime.onMessage.addListener(t),()=>{try{chrome.runtime.onMessage.removeListener(t)}catch{}}):void 0}catch{return}},[]);let l=t.length,d=l?Math.round(t.reduce((e,t)=>e+t.duration,0)/l):0,f=t.filter(e=>e.status>=400).length,S=l?Math.round(f/l*1e3)/10:0,C=t.filter(e=>e.isDuplicate).length,w=r!==`paused`,T=t.length>=3,E=d<500?`var(--api-success)`:d<1500?`var(--api-warning)`:`var(--api-danger)`,D=S===0?`var(--api-success)`:S<=5?`var(--api-warning)`:`var(--api-danger)`,O=G(e.overlayPosition);return r===`minimised`?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`style`,{children:g}),(0,s.jsxs)(`button`,{className:`apidbg-minimised ${O}`,onClick:()=>i(`feed`),children:[(0,s.jsx)(_,{isCapturing:!0}),(0,s.jsx)(`span`,{children:`API`}),(0,s.jsx)(`span`,{style:{color:`var(--api-text-subtle)`,fontSize:10},children:`^`})]})]}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`style`,{children:g}),(0,s.jsxs)(`div`,{className:`apidbg-overlay ${O}`,children:[(0,s.jsxs)(`div`,{className:`apidbg-header`,children:[(0,s.jsxs)(`div`,{className:`apidbg-title-row`,children:[(0,s.jsxs)(`div`,{className:`apidbg-title`,children:[(0,s.jsx)(_,{isCapturing:w}),(0,s.jsx)(`span`,{children:`API Debugger`})]}),(0,s.jsxs)(`div`,{className:`apidbg-actions`,children:[(0,s.jsx)(`button`,{className:`apidbg-icon-button`,onClick:()=>i(w?`paused`:`feed`),"aria-label":w?`Pause capture`:`Resume capture`,title:w?`Pause`:`Resume`,children:w?(0,s.jsx)(v,{}):(0,s.jsx)(y,{})}),(0,s.jsx)(`button`,{className:`apidbg-icon-button`,onClick:()=>{p({type:`OPEN_SIDE_PANEL`})},"aria-label":`Open side panel`,title:`Open side panel`,children:(0,s.jsx)(b,{})}),(0,s.jsx)(`button`,{className:`apidbg-icon-button`,onClick:()=>i(`minimised`),"aria-label":`Minimise overlay`,title:`Minimise`,children:(0,s.jsx)(x,{})})]})]}),t.length>0&&(0,s.jsxs)(`div`,{className:`apidbg-chip-row`,children:[(0,s.jsx)(j,{label:`${l} calls`,color:`var(--api-text-muted)`}),(0,s.jsx)(j,{label:`avg ${d}ms`,color:E}),(0,s.jsx)(j,{label:`${S}% errors`,color:D}),(0,s.jsx)(j,{label:`${C} dupes`,color:C>0?`var(--api-warning)`:`var(--api-text-muted)`})]})]}),T&&(0,s.jsx)(V,{requests:t}),r===`paused`&&(0,s.jsxs)(`div`,{className:`apidbg-paused`,children:[(0,s.jsxs)(`span`,{children:[`Capture paused - `,t.length,` requests buffered`]}),(0,s.jsx)(`button`,{className:`apidbg-link-button`,onClick:()=>i(`feed`),children:`Resume`})]}),(0,s.jsxs)(`div`,{className:`apidbg-list apidbg-scroll${r===`paused`?` is-paused`:``}`,children:[a&&(0,s.jsx)(`div`,{className:`apidbg-sweep`}),t.length===0?(0,s.jsx)(W,{}):t.map(e=>(0,s.jsx)(U,{req:e},e.id))]}),t.length>0&&(0,s.jsx)(`div`,{className:`apidbg-footer`,children:(0,s.jsx)(`button`,{className:`apidbg-plain-button`,onClick:()=>{c(!0),window.setTimeout(()=>{n([]),p({type:`CLEAR_SESSION`}),c(!1)},300)},children:`Clear`})})]})]})}var q=new Map,J=null;function Y(){let e=d();return(0,o.useEffect)(()=>(J=e,()=>{J=null}),[e]),(0,s.jsx)(K,{})}function X(e){window.postMessage({source:`api-debugger-content`,type:`API_DEBUGGER_SETTINGS`,payload:e},`*`)}async function Z(){let e;try{e=await i()}catch{return}let t=document.createElement(`script`);try{t.src=chrome.runtime.getURL(`src/injected/index.js`)}catch{return}if(t.onload=()=>{X(e),t.remove()},(document.head??document.documentElement).prepend(t),window.addEventListener(`message`,e=>{if(e.source===window&&e.data?.source===`api-debugger-injected`){if(e.data?.type===`API_DEBUGGER_REPLAY_RESULT`){let t=q.get(e.data.requestId);t&&(q.delete(e.data.requestId),t(e.data.payload));return}p(e.data)}}),f())try{chrome.runtime.onMessage.addListener((e,t,n)=>{if(e.type!==`EXECUTE_REPLAY`)return!1;let r=crypto.randomUUID(),i=window.setTimeout(()=>{let e=q.get(r);e&&(q.delete(r),e({status:0,duration:0,responseBody:`Replay timed out.`,responseHeaders:{}}))},3e4);return q.set(r,e=>{window.clearTimeout(i),n(e)}),window.postMessage({source:`api-debugger-content`,type:`API_DEBUGGER_REPLAY`,requestId:r,payload:e.payload},`*`),!0})}catch{}let n=document.createElement(`div`);n.id=`api-debugger-root`;let r=n.attachShadow({mode:`open`});document.documentElement.appendChild(n);let o=document.createElement(`div`);r.appendChild(o),(0,a.createRoot)(o).render((0,s.jsx)(l,{initialSettings:e,children:(0,s.jsx)(Y,{})}));try{chrome.storage.onChanged.addListener((t,n)=>{n!==`local`&&n!==`sync`||i().then(t=>{e=t,X(e),J?.(e)}).catch(()=>{})})}catch{}}Z().catch(()=>{});