import{i as e,n as t,r as n,t as r}from"./jsx-runtime-Cd5gl7hL.js";import{n as i}from"./settings-Btia4n2s.js";import"./src-E9QFfNHd.js";var a=e(n(),1),o=t(),s=r();function c(e){return typeof e==`object`&&!!e&&`type`in e&&e.type===`SESSION_UPDATED`&&`tabId`in e&&`payload`in e}function l(e){return typeof e==`object`&&!!e&&`type`in e&&e.type===`REPLAY_TARGET_SELECTED`&&`tabId`in e&&`payload`in e}function u(e){return typeof e==`object`&&!!e&&`type`in e&&e.type===`DEPENDENCIES_UPDATED`&&`payload`in e}function d(){let[e,t]=(0,a.useState)(`session`),[n,r]=(0,a.useState)(null),[i,o]=(0,a.useState)([]),[d,m]=(0,a.useState)(null);return(0,a.useEffect)(()=>{let e=!1,n=()=>{chrome.runtime.sendMessage({type:`GET_SESSION`}).then(t=>{e||!t||(r(t.tabId),o(t.requests))}).catch(()=>{e||(r(null),o([]))}),chrome.runtime.sendMessage({type:`GET_REPLAY_TARGET`}).then(n=>{e||!n||(r(e=>e??n.tabId),m(n.request),n.request&&t(`replay`))}).catch(()=>{e||m(null)})},i=e=>{if(l(e)){r(e.tabId),m(e.payload),t(`replay`);return}if(u(e)){o(t=>t.map(t=>t.id===e.payload.requestId?{...t,dependsOn:e.payload.dependsOn}:t));return}c(e)&&r(t=>t===e.tabId||t==null?(o(e.payload),e.tabId):t)};return n(),chrome.runtime.onMessage.addListener(i),window.addEventListener(`focus`,n),document.addEventListener(`visibilitychange`,n),()=>{e=!0,chrome.runtime.onMessage.removeListener(i),window.removeEventListener(`focus`,n),document.removeEventListener(`visibilitychange`,n)}},[]),(0,s.jsxs)(`div`,{className:`api-theme-shell api-sidepanel`,children:[(0,s.jsxs)(`header`,{className:`api-sidepanel-header`,children:[(0,s.jsx)(`span`,{className:`api-sidepanel-title`,children:`API Debugger`}),n!=null&&(0,s.jsxs)(`span`,{className:`api-muted`,children:[`Tab `,n]}),(0,s.jsx)(`button`,{className:`api-sidepanel-close`,type:`button`,title:`Close`,"aria-label":`Close side panel`,onClick:()=>{window.close()},children:`x`})]}),(0,s.jsx)(`nav`,{className:`api-sidepanel-tabs`,"aria-label":`Side panel views`,children:[[`session`,`Session`],[`deps`,`Dependency Map`],[`replay`,`Replay`]].map(([n,r])=>(0,s.jsx)(`button`,{className:`api-sidepanel-tab${e===n?` is-active`:``}`,onClick:()=>t(n),"aria-pressed":e===n,children:r},n))}),(0,s.jsxs)(`main`,{className:`api-sidepanel-content api-scroll`,children:[e===`session`&&(0,s.jsx)(f,{requests:i}),e===`deps`&&(0,s.jsx)(p,{requests:i}),e===`replay`&&(0,s.jsx)(_,{tabId:n,request:d,originalRequest:i.find(e=>e.id===d?.id)??null},d?.id??`empty-replay`)]})]})}function f({requests:e}){let[t,n]=(0,a.useState)(``),r=e.length,i=r?Math.round(e.reduce((e,t)=>e+t.duration,0)/r):0,o=e.filter(e=>e.status>=400).length,c=r?Math.round(o/r*1e3)/10:0,l=Math.round(r*1.2),u=i<500?`var(--api-success)`:i<1500?`var(--api-warning)`:`var(--api-danger)`,d=c===0?`var(--api-success)`:c<=5?`var(--api-warning)`:`var(--api-danger)`,f=new Map;e.forEach(e=>{let t=z(e.url),n=`${e.method} ${t}`,r=f.get(n)??{method:e.method,url:t,total:0,ttfbTotal:0,ttfbCount:0,count:0};r.total+=e.duration,e.ttfb>0&&(r.ttfbTotal+=e.ttfb,r.ttfbCount+=1),r.count+=1,f.set(n,r)});let p=Array.from(f.values()).map(e=>({...e,avg:Math.round(e.total/e.count),avgTtfb:e.ttfbCount>0?Math.round(e.ttfbTotal/e.ttfbCount):0})).sort((e,t)=>t.avg-e.avg).slice(0,5);return(0,s.jsxs)(`div`,{children:[(0,s.jsxs)(`div`,{className:`api-sidepanel-card-grid`,children:[(0,s.jsx)(v,{title:`Total Requests`,value:String(r),subtext:`${l}/min`}),(0,s.jsx)(v,{title:`Avg Latency`,value:V(i),subtext:`time to response`,valueColor:u}),(0,s.jsx)(v,{title:`Error Rate`,value:`${c}%`,subtext:`4xx + 5xx / total`,valueColor:d})]}),(0,s.jsxs)(`section`,{className:`api-sidepanel-section`,children:[(0,s.jsx)(y,{children:`Latency Timeline`}),(0,s.jsx)(b,{requests:e})]}),(0,s.jsxs)(`section`,{className:`api-sidepanel-section`,children:[(0,s.jsx)(y,{children:`Worst Offenders`}),p.length===0&&(0,s.jsx)(`div`,{className:`api-muted`,children:`No data yet.`}),p.map((e,t)=>(0,s.jsxs)(`div`,{className:`api-offender-row`,children:[(0,s.jsx)(`span`,{className:`api-offender-index`,children:t+1}),(0,s.jsx)(x,{method:e.method}),(0,s.jsx)(`span`,{className:`api-offender-path`,children:e.url}),(0,s.jsxs)(`span`,{style:{color:`var(--api-text-subtle)`,fontSize:11,fontFamily:`ui-monospace, monospace`},children:[`TTFB `,e.avgTtfb>0?V(e.avgTtfb):`-`]}),(0,s.jsx)(`span`,{style:{color:`var(--api-danger)`,fontSize:12,fontWeight:750},children:V(e.avg)})]},`${e.url}-${t}`))]}),(0,s.jsxs)(`section`,{className:`api-sidepanel-section`,children:[(0,s.jsx)(`button`,{className:`api-primary-wide`,onClick:()=>{n(``),E(e).then(e=>{n(`Saved ${e}`),window.setTimeout(()=>n(``),3500)}).catch(e=>{n(`Export failed: ${e instanceof Error?e.message:String(e)}`)})},disabled:e.length===0,children:`Export Session Report`}),t&&(0,s.jsx)(`div`,{className:`api-muted`,style:{marginTop:8,fontSize:12},children:t})]})]})}function p({requests:e}){let{nodes:t,edges:n}=(0,a.useMemo)(()=>{let t=new Map(e.map(e=>[e.id,e])),n=new Map,r=new Map;e.forEach(e=>{let t=z(e.url),r=n.get(t)??{id:t,label:B(t),count:0};r.count+=1,n.set(t,r)}),e.forEach(e=>{let i=z(e.url);e.dependsOn.forEach(a=>{let o=t.get(a);if(!o)return;let s=z(o.url);if(!n.has(s)||!n.has(i)||s===i)return;let c=`${s} -> ${i}`,l=r.get(c)??{from:s,to:i,latency:0,count:0};l.latency+=e.duration,l.count+=1,r.set(c,l)})});let i=Array.from(r.values()).map(e=>({...e,latency:Math.round(e.latency/e.count)})).sort((e,t)=>t.count-e.count||t.latency-e.latency),a=new Set(i.flatMap(e=>[e.from,e.to]));return{nodes:Array.from(n.values()).filter(e=>a.has(e.id)).sort((e,t)=>t.count-e.count||e.label.localeCompare(t.label)),edges:i}},[e]);if(n.length===0)return(0,s.jsxs)(`section`,{className:`api-sidepanel-section`,children:[(0,s.jsx)(y,{children:`API Dependency Graph`}),(0,s.jsx)(`p`,{className:`api-muted`,children:`Nodes = endpoints. Edges = inferred call chains. Node size = call frequency.`}),(0,s.jsxs)(`div`,{className:`api-dependency-empty`,children:[(0,s.jsx)(S,{}),(0,s.jsx)(`div`,{style:{fontSize:13},children:`No dependencies mapped yet`}),(0,s.jsx)(`div`,{style:{color:`var(--api-border-strong)`,fontSize:12},children:`Relationships appear after connected requests are captured.`})]})]});let r=new Map(t.map((e,n)=>{let r=n/t.length*Math.PI*2-Math.PI/2;return[e.id,{x:180+Math.cos(r)*122,y:180+Math.sin(r)*122}]}));return(0,s.jsxs)(`section`,{className:`api-sidepanel-section`,children:[(0,s.jsx)(y,{children:`API Dependency Graph`}),(0,s.jsx)(`p`,{className:`api-muted`,children:`Nodes = endpoints. Edges = inferred call chains. Node size = call frequency.`}),(0,s.jsxs)(`svg`,{viewBox:`0 0 360 360`,className:`api-dependency-graph`,role:`img`,"aria-label":`API dependency graph with ${t.length} endpoints and ${n.length} inferred dependencies`,children:[(0,s.jsx)(`desc`,{children:`Directed edges show inferred request chains. Node size represents call frequency and edge color represents average latency.`}),(0,s.jsx)(`defs`,{children:(0,s.jsx)(`marker`,{id:`api-arrow`,markerWidth:`8`,markerHeight:`8`,refX:`7`,refY:`4`,orient:`auto`,children:(0,s.jsx)(`path`,{d:`M0,0 L8,4 L0,8 Z`,fill:`var(--api-border-strong)`})})}),n.map((e,t)=>{let n=r.get(e.from),i=r.get(e.to);if(!n||!i)return null;let a=U(e.latency);return(0,s.jsxs)(`g`,{children:[(0,s.jsx)(`path`,{d:`M ${n.x.toFixed(1)} ${n.y.toFixed(1)} L ${i.x.toFixed(1)} ${i.y.toFixed(1)}`,fill:`none`,stroke:a,strokeWidth:`1.6`,markerEnd:`url(#api-arrow)`}),(0,s.jsxs)(`title`,{children:[B(e.from),` to `,B(e.to),` - avg `,V(e.latency)]})]},`${e.from}-${e.to}-${t}`)}),t.map(e=>{let t=r.get(e.id);return t?(0,s.jsx)(m,{x:t.x,y:t.y,radius:Math.min(20,8+e.count*1.5),label:e.label,fullPath:e.id,count:e.count},e.id):null}),(0,s.jsxs)(`g`,{transform:`translate(12, 338)`,fontSize:`10`,fill:`var(--api-text-subtle)`,children:[(0,s.jsx)(`line`,{x1:`0`,y1:`6`,x2:`20`,y2:`6`,stroke:`#22C55E`,strokeWidth:`1.5`}),(0,s.jsx)(`text`,{x:`26`,y:`9`,children:`Fast under 500ms`}),(0,s.jsx)(`line`,{x1:`136`,y1:`6`,x2:`156`,y2:`6`,stroke:`#F59E0B`,strokeWidth:`1.5`}),(0,s.jsx)(`text`,{x:`162`,y:`9`,children:`Slow 500ms+`}),(0,s.jsx)(`line`,{x1:`270`,y1:`6`,x2:`290`,y2:`6`,stroke:`#EF4444`,strokeWidth:`1.5`}),(0,s.jsx)(`text`,{x:`296`,y:`9`,children:`Very slow 1.5s+`})]})]}),(0,s.jsx)(`div`,{style:{display:`grid`,gap:6,marginTop:10},children:n.slice(0,8).map(e=>(0,s.jsxs)(`div`,{className:`api-muted`,style:{display:`grid`,gridTemplateColumns:`1fr auto 1fr`,gap:8,alignItems:`center`,fontSize:11},children:[(0,s.jsx)(`span`,{title:e.from,style:{overflow:`hidden`,textOverflow:`ellipsis`,whiteSpace:`nowrap`},children:B(e.from)}),(0,s.jsxs)(`span`,{style:{color:U(e.latency),fontFamily:`ui-monospace, monospace`},children:[`->`,` `,V(e.latency)]}),(0,s.jsx)(`span`,{title:e.to,style:{overflow:`hidden`,textOverflow:`ellipsis`,whiteSpace:`nowrap`},children:B(e.to)})]},`${e.from}-${e.to}`))})]})}function m({x:e,y:t,radius:n,label:r,fullPath:i,count:a}){return(0,s.jsxs)(`g`,{children:[(0,s.jsx)(`circle`,{cx:e,cy:t,r:n,fill:`var(--api-surface)`,stroke:`var(--api-color-primary-soft)`,strokeWidth:`1.5`,children:(0,s.jsx)(`title`,{children:i})}),(0,s.jsx)(`circle`,{cx:e+n-2,cy:t-n+2,r:`8`,fill:`var(--api-color-primary)`,stroke:`var(--api-bg)`,strokeWidth:`1.5`}),(0,s.jsx)(`text`,{x:e+n-2,y:t-n+5,fill:`var(--api-text)`,fontSize:`8`,fontWeight:`800`,textAnchor:`middle`,children:a}),(0,s.jsx)(`text`,{x:e,y:t+n+13,fill:`var(--api-text)`,fontSize:`10`,fontWeight:`700`,textAnchor:`middle`,children:r})]})}function h(e){let t=Object.entries(e).map(([e,t])=>({k:e,v:t}));return t.length>0?t:[{k:``,v:``}]}function g(e){return e.reduce((e,t)=>{let n=t.k.trim();return n&&(e[n]=t.v),e},{})}function _({tabId:e,request:t,originalRequest:n}){let r=(0,a.useRef)(null),[i,o]=(0,a.useState)(t?.method??`GET`),[c,l]=(0,a.useState)(t?.url??``),[u,d]=(0,a.useState)(h(t?.headers??{})),[f,p]=(0,a.useState)(t?.body??``),[m,_]=(0,a.useState)(!1),[v,b]=(0,a.useState)(null),[S,E]=(0,a.useState)(``),D=f.split(`
`).map((e,t)=>t+1),O=g(u),k=/\bjson\b/i.test(O[`content-type`]??``)||/^[\s[{]/.test(f.trim()),A=t?i!==t.method||c!==t.url||f!==(t.body??``)||JSON.stringify(O)!==JSON.stringify(t.headers):!1,j=()=>{if(!f.trim()){E(``);return}try{p(JSON.stringify(JSON.parse(f),null,2)),E(``)}catch{E(`Body is not valid JSON. Fix it before formatting or replaying.`)}},M=()=>{o(t?.method??`GET`),l(t?.url??``),d(h(t?.headers??{})),p(t?.body??``),E(``),b(null)},N=()=>{if(!(!e||!c)){if(f.trim()&&k)try{JSON.parse(f),E(``)}catch{E(`Body is not valid JSON. Fix it before replaying.`);return}_(!0),b(null),chrome.runtime.sendMessage({type:`RUN_REPLAY`,tabId:e,payload:{id:t?.id??crypto.randomUUID(),method:i,url:c,headers:O,body:f.trim()?f:null,originalResponseBody:t?.originalResponseBody??null}}).then(e=>{b(e)}).catch(e=>{b({status:0,duration:0,responseBody:String(e),responseHeaders:{}})}).finally(()=>{_(!1)})}},P=w(t?.originalResponseBody??``,v?.responseBody??``),F=T(P);return(0,a.useEffect)(()=>{let e=r.current;if(!e)return;e.querySelector(`select, input, textarea, button:not(:disabled)`)?.focus();let t=t=>{if(t.key!==`Tab`)return;let n=Array.from(e.querySelectorAll(`button:not(:disabled), [href], input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])`)).filter(e=>!e.hasAttribute(`hidden`)&&e.offsetParent!==null);if(n.length===0)return;let r=n[0],i=n[n.length-1];if(t.shiftKey&&document.activeElement===r){t.preventDefault(),i.focus();return}!t.shiftKey&&document.activeElement===i&&(t.preventDefault(),r.focus())};return e.addEventListener(`keydown`,t),()=>e.removeEventListener(`keydown`,t)},[t?.id]),(0,s.jsxs)(`div`,{className:`api-replay`,ref:r,role:`region`,"aria-label":`Request replay editor`,children:[t&&(0,s.jsxs)(`div`,{className:`api-replay-summary`,children:[(0,s.jsxs)(`div`,{className:`api-replay-summary-row`,children:[(0,s.jsx)(x,{method:t.method}),(0,s.jsx)(`span`,{className:`api-muted`,children:z(t.url)}),n&&(0,s.jsxs)(`span`,{className:`api-muted`,children:[`Original `,V(n.duration),` · `,n.status]})]}),(0,s.jsxs)(`div`,{className:`api-replay-summary-row`,children:[(0,s.jsx)(`span`,{className:`api-replay-badge${A?` is-dirty`:``}`,children:A?`Edited`:`Original values`}),n?.ttfb?(0,s.jsxs)(`span`,{className:`api-muted`,children:[`TTFB `,V(n.ttfb)]}):null,n?(0,s.jsxs)(`span`,{className:`api-muted`,children:[`Resp `,H(n.responseSize)]}):null,n?.timingSource?(0,s.jsxs)(`span`,{className:`api-muted`,children:[`Source `,n.timingSource===`performance`?`Browser`:n.timingSource.toUpperCase()]}):null]})]}),(0,s.jsxs)(`div`,{className:`api-replay-row`,children:[(0,s.jsx)(`select`,{className:`api-replay-select api-replay-method`,value:i,onChange:e=>o(e.target.value),"aria-label":`Replay HTTP method`,children:[`GET`,`POST`,`PUT`,`PATCH`,`DELETE`].map(e=>(0,s.jsx)(`option`,{children:e},e))}),(0,s.jsx)(`input`,{className:`api-replay-input`,value:c,onChange:e=>l(e.target.value),"aria-label":`Replay request URL`})]}),(0,s.jsxs)(`div`,{children:[(0,s.jsxs)(`div`,{className:`api-replay-section-head`,children:[(0,s.jsx)(y,{children:`Headers`}),(0,s.jsxs)(`span`,{className:`api-muted`,children:[Object.keys(O).length,` active`]})]}),u.map((e,t)=>(0,s.jsxs)(`div`,{className:`api-header-row`,style:{marginBottom:6},children:[(0,s.jsx)(`input`,{className:`api-replay-input`,value:e.k,placeholder:`Key`,"aria-label":`Header ${t+1} key`,onChange:e=>{let n=[...u];n[t]={...n[t],k:e.target.value},d(n)}}),(0,s.jsx)(`input`,{className:`api-replay-input`,value:e.v,placeholder:`Value`,"aria-label":`Header ${t+1} value`,onChange:e=>{let n=[...u];n[t]={...n[t],v:e.target.value},d(n)}}),(0,s.jsx)(`button`,{className:`api-sidepanel-plain`,"aria-label":`Remove header ${t+1}`,onClick:()=>d(u.filter((e,n)=>n!==t)),children:`x`})]},t)),(0,s.jsx)(`button`,{className:`api-sidepanel-plain`,onClick:()=>d([...u,{k:``,v:``}]),children:`+ Add header`})]}),(0,s.jsxs)(`div`,{children:[(0,s.jsxs)(`div`,{className:`api-replay-section-head`,children:[(0,s.jsx)(y,{children:`Body`}),(0,s.jsxs)(`div`,{className:`api-replay-tools`,children:[(0,s.jsx)(`button`,{className:`api-sidepanel-plain`,type:`button`,onClick:j,children:`Format JSON`}),(0,s.jsx)(`button`,{className:`api-sidepanel-plain`,type:`button`,onClick:M,children:`Reset`})]})]}),(0,s.jsxs)(`div`,{className:`api-body-editor`,children:[(0,s.jsx)(`div`,{className:`api-line-numbers`,children:D.map(e=>(0,s.jsx)(`div`,{children:e},e))}),(0,s.jsx)(`textarea`,{className:`api-replay-textarea`,value:f,onChange:e=>p(e.target.value),"aria-label":`Replay request body`})]}),S&&(0,s.jsx)(`div`,{className:`api-replay-error`,children:S})]}),(0,s.jsxs)(`button`,{className:`api-primary-wide`,onClick:N,disabled:m||!e||!c,"aria-busy":m,children:[m&&(0,s.jsx)(`span`,{className:`api-spinner`}),m?`Sending...`:`Send Request`]}),!t&&!v?(0,s.jsxs)(`div`,{className:`api-replay-empty`,children:[(0,s.jsx)(`span`,{style:{color:`var(--api-border-strong)`,fontSize:32},children:`↻`}),(0,s.jsx)(`div`,{style:{fontSize:13},children:`No replay yet`}),(0,s.jsx)(`div`,{style:{color:`var(--api-border-strong)`,fontSize:11},children:`Click Replay on a captured request in the overlay.`})]}):v?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(`div`,{className:`api-replay-result`,children:[(0,s.jsxs)(`div`,{className:`api-replay-summary-row`,children:[(0,s.jsx)(`span`,{className:`api-replay-badge${v.status>=400||v.status===0?` is-error`:` is-success`}`,children:v.status||`failed`}),(0,s.jsxs)(`span`,{className:`api-muted`,children:[`Replay completed in `,V(v.duration)]}),(0,s.jsx)(`span`,{className:`api-muted`,children:v.responseHeaders[`content-type`]??`unknown content-type`})]}),(0,s.jsxs)(`div`,{className:`api-replay-summary-row`,children:[(0,s.jsxs)(`span`,{className:`api-muted`,children:[F.same,` unchanged`]}),(0,s.jsxs)(`span`,{className:`api-muted`,children:[F.added,` added`]}),(0,s.jsxs)(`span`,{className:`api-muted`,children:[F.removed,` removed`]})]})]}),(0,s.jsxs)(`div`,{className:`api-diff-grid`,children:[(0,s.jsx)(C,{title:`Original Response`,lines:P.left}),(0,s.jsx)(C,{title:`Replay Response`,lines:P.right})]})]}):(0,s.jsxs)(`div`,{className:`api-replay-empty`,children:[(0,s.jsx)(`span`,{style:{color:`var(--api-border-strong)`,fontSize:32},children:`↻`}),(0,s.jsx)(`div`,{style:{fontSize:13},children:`Ready to replay`}),(0,s.jsx)(`div`,{style:{color:`var(--api-border-strong)`,fontSize:11},children:`Edit the request and send it from the original tab.`})]})]})}function v({title:e,value:t,subtext:n,valueColor:r=`var(--api-text)`}){return(0,s.jsxs)(`div`,{className:`api-stat-card`,children:[(0,s.jsx)(`div`,{className:`api-stat-title`,children:e}),(0,s.jsx)(`div`,{className:`api-stat-value`,style:{"--stat-color":r},children:t}),(0,s.jsx)(`div`,{className:`api-stat-subtext`,children:n})]})}function y({children:e}){return(0,s.jsx)(`div`,{className:`api-section-heading`,children:e})}function b({requests:e}){let t=(0,a.useRef)(null),[n,r]=(0,a.useState)(null);return(0,a.useEffect)(()=>{let n=t.current;if(!n)return;let r=window.devicePixelRatio||1,i=n.clientWidth,a=n.clientHeight;n.width=i*r,n.height=a*r;let o=n.getContext(`2d`);if(!o)return;let s=getComputedStyle(n),c=s.getPropertyValue(`--api-color-primary-soft`).trim()||`#cbb8ff`,l=s.getPropertyValue(`--api-border-strong`).trim()||`#5d536b`,u=s.getPropertyValue(`--api-success`).trim()||`#8fe6bc`,d=s.getPropertyValue(`--api-warning`).trim()||`#ffd36f`,f=s.getPropertyValue(`--api-danger`).trim()||`#ff8f8f`;if(o.scale(r,r),o.clearRect(0,0,i,a),e.length===0)return;let p=Math.max(...e.map(e=>e.duration),2e3);[500,1500].forEach(e=>{let t=a-e/p*(a-16)-8;o.setLineDash([4,4]),o.strokeStyle=l,o.globalAlpha=.35,o.beginPath(),o.moveTo(0,t),o.lineTo(i,t),o.stroke()}),o.globalAlpha=1,o.setLineDash([]);let m=e.map((t,n)=>({x:n/Math.max(1,e.length-1)*(i-16)+8,y:a-t.duration/p*(a-16)-8,request:t}));o.strokeStyle=c,o.globalAlpha=.45,o.lineWidth=1,o.beginPath(),m.forEach((e,t)=>t===0?o.moveTo(e.x,e.y):o.lineTo(e.x,e.y)),o.stroke(),o.globalAlpha=1,m.forEach(e=>{o.beginPath(),o.arc(e.x,e.y,3,0,Math.PI*2),o.fillStyle=e.request.status>=400?d:e.request.isSlow?f:u,o.fill()})},[e]),(0,s.jsxs)(`div`,{className:`api-latency-chart`,children:[(0,s.jsx)(`canvas`,{ref:t,role:`img`,"aria-label":`Latency chart for ${e.length} captured requests`,onMouseMove:t=>{let n=t.currentTarget.getBoundingClientRect(),i=t.clientX-n.left,a=e[Math.round(i/n.width*(e.length-1))];a&&r({x:t.clientX,y:t.clientY,r:a})},onMouseLeave:()=>r(null)}),n&&(0,s.jsxs)(`div`,{className:`api-chart-tooltip`,style:{top:n.y-56,left:n.x+8},children:[(0,s.jsx)(`div`,{children:z(n.r.url).slice(0,30)}),(0,s.jsxs)(`div`,{style:{color:`var(--api-text-muted)`},children:[Math.round(n.r.duration),`ms - `,n.r.status]})]})]})}function x({method:e}){let t={GET:{bg:`rgba(203, 184, 255, 0.18)`,color:`var(--api-color-primary-soft)`},POST:{bg:`rgba(143, 230, 188, 0.14)`,color:`var(--api-success)`},PUT:{bg:`rgba(201, 167, 77, 0.2)`,color:`var(--api-warning)`},PATCH:{bg:`rgba(128, 105, 191, 0.26)`,color:`var(--api-color-secondary-soft)`},DELETE:{bg:`rgba(255, 143, 143, 0.15)`,color:`var(--api-danger)`}},n=t[e.toUpperCase()]??t.GET;return(0,s.jsx)(`span`,{className:`api-method-pill`,style:{"--method-bg":n.bg,"--method-color":n.color},children:e})}function S(){return(0,s.jsxs)(`svg`,{width:`120`,height:`80`,viewBox:`0 0 120 80`,children:[(0,s.jsx)(`circle`,{cx:`20`,cy:`40`,r:`10`,fill:`none`,stroke:`var(--api-border-strong)`,strokeWidth:`1.5`,strokeDasharray:`3 3`}),(0,s.jsx)(`circle`,{cx:`60`,cy:`20`,r:`10`,fill:`none`,stroke:`var(--api-border-strong)`,strokeWidth:`1.5`,strokeDasharray:`3 3`}),(0,s.jsx)(`circle`,{cx:`60`,cy:`60`,r:`10`,fill:`none`,stroke:`var(--api-border-strong)`,strokeWidth:`1.5`,strokeDasharray:`3 3`}),(0,s.jsx)(`circle`,{cx:`100`,cy:`40`,r:`10`,fill:`none`,stroke:`var(--api-border-strong)`,strokeWidth:`1.5`,strokeDasharray:`3 3`}),(0,s.jsx)(`line`,{x1:`30`,y1:`40`,x2:`50`,y2:`22`,stroke:`var(--api-border-strong)`,strokeDasharray:`3 3`}),(0,s.jsx)(`line`,{x1:`30`,y1:`40`,x2:`50`,y2:`58`,stroke:`var(--api-border-strong)`,strokeDasharray:`3 3`}),(0,s.jsx)(`line`,{x1:`70`,y1:`22`,x2:`90`,y2:`38`,stroke:`var(--api-border-strong)`,strokeDasharray:`3 3`}),(0,s.jsx)(`line`,{x1:`70`,y1:`58`,x2:`90`,y2:`42`,stroke:`var(--api-border-strong)`,strokeDasharray:`3 3`})]})}function C({title:e,lines:t}){return(0,s.jsxs)(`div`,{className:`api-diff-panel`,children:[(0,s.jsx)(`div`,{className:`api-diff-title`,children:e}),(0,s.jsx)(`pre`,{className:`api-diff-code`,children:t.map((e,t)=>(0,s.jsxs)(`div`,{className:`api-diff-line${e.kind===`add`?` is-add`:``}${e.kind===`del`?` is-del`:``}`,children:[e.kind===`del`?`- `:e.kind===`add`?`+ `:`  `,e.text]},t))})]})}function w(e,t){let n=e.split(`
`),r=t.split(`
`),i=new Set(n),a=new Set(r);return{left:n.map(e=>({text:e,kind:a.has(e)?`same`:`del`})),right:r.map(e=>({text:e,kind:i.has(e)?`same`:`add`}))}}function T(e){return{same:e.right.filter(e=>e.kind===`same`).length,added:e.right.filter(e=>e.kind===`add`).length,removed:e.left.filter(e=>e.kind===`del`).length}}async function E(e){if(e.length===0)throw Error(`No requests captured yet.`);let t=O(e,(await i()).largePayloadThresholdKb),n=new Blob([t],{type:`text/html;charset=utf-8`}),r=URL.createObjectURL(n),a=`api-debugger-session-${new Date().toISOString().replaceAll(`:`,`-`).replace(/\.\d{3}Z$/,`Z`)}.html`;try{return chrome.downloads?.download?await chrome.downloads.download({url:r,filename:a,saveAs:!0}):D(r,a),a}catch{return D(r,a),a}finally{window.setTimeout(()=>URL.revokeObjectURL(r),5e3)}}function D(e,t){let n=document.createElement(`a`);n.href=e,n.download=t,n.rel=`noopener`,document.body.append(n),n.click(),n.remove()}function O(e,t){let n=new Date,r=e.length,i=r?Math.round(e.reduce((e,t)=>e+t.duration,0)/r):0,a=e.filter(e=>e.status>=400).length,o=r?Math.round(a/r*1e3)/10:0,s=e.filter(e=>e.isDuplicate).length,c=e.filter(e=>P(e,t)).length,l=e.filter(e=>e.status===0).length,u=e.filter(e=>e.requestBody!=null&&e.requestBody!==``).length,d=e.filter(e=>e.responseBody!=null&&e.responseBody!==``).length,f=[...e].sort((e,t)=>t.duration-e.duration)[0],p=e.filter(e=>e.aiSuggestion),m=e.map(e=>`
    <tr>
      <td><span class="method">${L(e.method)}</span></td>
      <td><span class="url">${L(e.url)}</span></td>
      <td class="${e.status>=500?`danger`:e.status>=400?`warning`:`success`}">${e.status||`-`}</td>
      <td>${V(e.duration)}</td>
      <td>${H(e.requestSize)}</td>
      <td>${H(e.responseSize)}</td>
      <td>${e.ttfb>0?V(e.ttfb):`-`}</td>
      <td><span class="source source-${e.timingSource}">${N(e.timingSource)}</span></td>
      <td>${F(e,t)}</td>
      <td>${L(new Date(e.startTime).toLocaleTimeString())}</td>
    </tr>
    <tr class="details-row">
      <td colspan="10">
        <details>
          <summary>Payload and timing details</summary>
          <div class="timing-grid">
            ${I(e,t)}
          </div>
          <div class="payload-grid">
            <div>
              <h3>Request</h3>
              <pre>${L(M({headers:e.requestHeaders,body:e.requestBody,captureNote:e.requestBody==null&&e.requestSize>0?`[request body unavailable in capture, ${H(e.requestSize)} transferred]`:void 0,fingerprint:e.fingerprint,duplicateOf:e.duplicateOf},e.requestBody,e.requestSize,`request`))}</pre>
            </div>
            <div>
              <h3>Response</h3>
              <pre>${L(M(e.responseBody,e.responseBody,e.responseSize,`response`))}</pre>
            </div>
            ${e.aiSuggestion?`
              <div>
                <h3>AI Suggestion</h3>
                <pre>${L(e.aiSuggestion)}</pre>
              </div>
            `:``}
          </div>
        </details>
      </td>
    </tr>
  `).join(``);return`<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>API Debugger Session Report</title>
  <style>
    :root {
      color-scheme: dark;
      --bg: #121015;
      --surface: #1e1b22;
      --raised: #292630;
      --border: #403a49;
      --border-strong: #5d536b;
      --text: #eee8f5;
      --muted: #9c96a6;
      --subtle: #79737f;
      --primary: #cbb8ff;
      --success: #8fe6bc;
      --warning: #ffd36f;
      --danger: #ff8f8f;
    }

    * { box-sizing: border-box; }
    body {
      margin: 0;
      background: var(--bg);
      color: var(--text);
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      line-height: 1.5;
    }
    main {
      width: min(1180px, calc(100vw - 32px));
      margin: 0 auto;
      padding: 28px 0 48px;
    }
    header {
      display: flex;
      justify-content: space-between;
      gap: 16px;
      align-items: flex-start;
      margin-bottom: 22px;
      border-bottom: 1px solid var(--border);
      padding-bottom: 18px;
    }
    h1, h2, h3 { margin: 0; }
    h1 { font-size: 24px; }
    h2 { margin: 26px 0 12px; font-size: 16px; }
    h3 { margin-bottom: 8px; color: var(--muted); font-size: 12px; text-transform: uppercase; }
    .muted { color: var(--muted); }
    .stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 10px;
    }
    .card {
      border: 1px solid var(--border);
      border-radius: 8px;
      background: var(--surface);
      padding: 12px;
    }
    .label {
      color: var(--subtle);
      font-size: 11px;
      text-transform: uppercase;
    }
    .value {
      margin-top: 4px;
      font-size: 22px;
      font-weight: 800;
    }
    .chart, .graph {
      width: 100%;
      min-height: 160px;
      border: 1px solid var(--border);
      border-radius: 8px;
      background: var(--surface);
      padding: 12px;
      overflow: auto;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      border: 1px solid var(--border);
      background: var(--surface);
      font-size: 12px;
    }
    th, td {
      border-bottom: 1px solid var(--border);
      padding: 8px;
      text-align: left;
      vertical-align: top;
    }
    th {
      color: var(--subtle);
      font-size: 11px;
      text-transform: uppercase;
      background: var(--raised);
    }
    .url {
      display: inline-block;
      max-width: 420px;
      overflow-wrap: anywhere;
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      color: var(--muted);
    }
    .method, .badge {
      display: inline-flex;
      margin-right: 4px;
      border-radius: 4px;
      padding: 2px 6px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 11px;
      font-weight: 800;
    }
    .method { background: rgba(203, 184, 255, 0.16); color: var(--primary); }
    .badge { border: 1px solid var(--border-strong); }
    .warn-bg { background: rgba(201, 167, 77, 0.18); color: var(--warning); }
    .danger-bg { background: rgba(255, 143, 143, 0.14); color: var(--danger); }
    .source {
      display: inline-flex;
      border: 1px solid var(--border-strong);
      border-radius: 999px;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 10px;
      font-weight: 800;
      white-space: nowrap;
    }
    .source-cdp { background: rgba(143, 230, 188, 0.12); color: var(--success); }
    .source-performance { background: rgba(137, 194, 255, 0.12); color: #89c2ff; }
    .source-proxy { background: rgba(201, 167, 77, 0.16); color: var(--warning); }
    .success { color: var(--success); }
    .warning { color: var(--warning); }
    .danger { color: var(--danger); }
    details summary { cursor: pointer; color: var(--primary); }
    .details-row td { background: #18151d; padding: 8px 12px; }
    .timing-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
      gap: 8px;
      margin-top: 10px;
      margin-bottom: 10px;
    }
    .timing-cell {
      border: 1px solid var(--border);
      border-radius: 6px;
      background: var(--surface);
      padding: 8px;
    }
    .timing-cell .label {
      display: block;
      margin-bottom: 3px;
      font-size: 10px;
    }
    .timing-cell .value {
      margin: 0;
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 13px;
    }
    .payload-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 12px;
      margin-top: 10px;
    }
    pre {
      max-height: 340px;
      margin: 0;
      overflow: auto;
      border: 1px solid var(--border);
      border-radius: 6px;
      background: #111014;
      color: var(--muted);
      padding: 10px;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
    }
    .suggestion {
      border-left: 3px solid var(--primary);
      border-radius: 6px;
      background: var(--surface);
      padding: 12px;
      margin-bottom: 10px;
    }
    .callout {
      margin-top: 12px;
      border: 1px solid var(--border);
      border-left: 3px solid var(--primary);
      border-radius: 8px;
      background: rgba(41, 38, 48, 0.52);
      color: var(--muted);
      padding: 12px 14px;
      font-size: 12px;
    }
  </style>
</head>
<body>
  <main>
    <header>
      <div>
        <h1>API Debugger Session Report</h1>
        <div class="muted">Generated ${L(n.toLocaleString())}</div>
      </div>
      <div class="muted">${r} captured requests</div>
    </header>

    <section class="stats">
      <div class="card"><div class="label">Total Requests</div><div class="value">${r}</div></div>
      <div class="card"><div class="label">Average Latency</div><div class="value">${V(i)}</div></div>
      <div class="card"><div class="label">Error Rate</div><div class="value">${o}%</div></div>
      <div class="card"><div class="label">Duplicate Calls</div><div class="value">${s}</div></div>
      <div class="card"><div class="label">Failed / Aborted</div><div class="value">${l}</div></div>
      <div class="card"><div class="label">Large Payloads</div><div class="value">${c}</div><div class="muted">over ${H(t*1024)}</div></div>
      <div class="card"><div class="label">Slowest Endpoint</div><div class="value" style="font-size: 13px; overflow-wrap: anywhere;">${f?L(`${V(f.duration)} ${z(f.url)}`):`-`}</div></div>
    </section>

    <h2>Capture Fidelity</h2>
    <section class="stats">
      <div class="card"><div class="label">Captured Request Bodies</div><div class="value">${u}</div><div class="muted">${r-u} unavailable or empty</div></div>
      <div class="card"><div class="label">Captured Response Bodies</div><div class="value">${d}</div><div class="muted">${r-d} unavailable or empty</div></div>
      <div class="card"><div class="label">Report Validation</div><div class="value">OK</div><div class="muted">Built from ${r} live session entries</div></div>
    </section>
    <div class="callout">
      Binary, oversized, unreadable, aborted, and restricted-environment payloads are rendered with explicit placeholders so the exported report mirrors the live capture state.
    </div>

    <h2>Latency Timeline</h2>
    <div class="chart">${k(e)}</div>

    <h2>Dependency Map</h2>
    <div class="graph">${A(e)}</div>

    <h2>Request Feed</h2>
    <table>
      <thead>
        <tr>
          <th>Method</th>
          <th>URL</th>
          <th>Status</th>
          <th>Duration</th>
          <th>Req Size</th>
          <th>Resp Size</th>
          <th>TTFB</th>
          <th>Source</th>
          <th>Flags</th>
          <th>Time</th>
        </tr>
      </thead>
      <tbody>${m}</tbody>
    </table>

    <h2>AI Suggestions</h2>
    ${p.length>0?p.map(e=>`
        <div class="suggestion">
          <div class="muted">${L(e.method)} ${L(z(e.url))}</div>
          <div>${L(e.aiSuggestion??``)}</div>
        </div>
      `).join(``):`<div class="muted">No AI suggestions were captured in this session.</div>`}
  </main>
</body>
</html>`}function k(e){if(e.length===0)return`<div class="muted">No requests were captured in this session.</div>`;let t=Math.max(...e.map(e=>e.duration),100),n=Math.round(e.reduce((e,t)=>e+t.duration,0)/e.length),r=e.map((n,r)=>({x:34+r/Math.max(1,e.length-1)*912,y:206-n.duration/t*154,request:n})),i=r.map((e,t)=>`${t===0?`M`:`L`} ${e.x.toFixed(1)} ${e.y.toFixed(1)}`).join(` `),a=r.length>0?`${i} L ${r.at(-1)?.x.toFixed(1)} 206 L ${r[0].x.toFixed(1)} 206 Z`:``,o=206-n/t*154,s=[0,.25,.5,.75,1].map(e=>{let n=Math.round(t*e),r=206-e*154;return`
      <line x1="34" y1="${r.toFixed(1)}" x2="946" y2="${r.toFixed(1)}" stroke="#403a49" stroke-width="1" opacity="${e===0?`1`:`0.45`}" />
      <text x="26" y="${(r+4).toFixed(1)}" fill="#79737f" font-size="10" text-anchor="end">${V(n)}</text>
    `}).join(``),c=r.map(e=>`
    <circle cx="${e.x.toFixed(1)}" cy="${e.y.toFixed(1)}" r="${e.request.isSlow||e.request.status>=400?`5`:`3.5`}" fill="${e.request.isSlow?`#ff8f8f`:e.request.status>=400?`#ffd36f`:`#8fe6bc`}" stroke="#121015" stroke-width="1.5">
      <title>${L(`${e.request.method} ${z(e.request.url)} - ${V(e.request.duration)} - ${N(e.request.timingSource)}`)}</title>
    </circle>
  `).join(``),l=[[`#8fe6bc`,`2xx / fast`],[`#ffd36f`,`4xx / warning`],[`#ff8f8f`,`Slow / 5xx`]].map(([e,t],n)=>`
    <g transform="translate(${680+n*100}, 18)">
      <circle cx="0" cy="0" r="4" fill="${e}" />
      <text x="9" y="4" fill="#9c96a6" font-size="10">${t}</text>
    </g>
  `).join(``);return`<svg viewBox="0 0 980 240" width="100%" height="240" role="img" aria-label="Latency timeline">
    <defs>
      <linearGradient id="latency-fill" x1="0" x2="0" y1="0" y2="1">
        <stop offset="0%" stop-color="#cbb8ff" stop-opacity="0.28" />
        <stop offset="100%" stop-color="#cbb8ff" stop-opacity="0.02" />
      </linearGradient>
    </defs>
    <rect x="0" y="0" width="980" height="240" rx="8" fill="#18151d" />
    <text x="34" y="22" fill="#eee8f5" font-size="13" font-weight="800">Latency over session</text>
    <text x="34" y="39" fill="#79737f" font-size="10">Average ${V(n)} across ${e.length} requests</text>
    ${l}
    ${s}
    <line x1="34" y1="${o.toFixed(1)}" x2="946" y2="${o.toFixed(1)}" stroke="#ffd36f" stroke-width="1" stroke-dasharray="4 5" opacity="0.75" />
    <text x="946" y="${(o-6).toFixed(1)}" fill="#ffd36f" font-size="10" text-anchor="end">avg ${V(n)}</text>
    <path d="${a}" fill="url(#latency-fill)" />
    <path d="${i}" fill="none" stroke="#cbb8ff" stroke-width="2" opacity="0.8" />
    ${c}
  </svg>`}function A(e){let t=new Map(e.map(e=>[e.id,e])),n=new Map;e.forEach(e=>{let t=z(e.url);n.set(t,(n.get(t)??0)+1)});let r=new Map;e.forEach(e=>{let n=z(e.url);e.dependsOn.forEach(i=>{let a=t.get(i);if(!a)return;let o=z(a.url);if(o===n)return;let s=`${o} -> ${n}`,c=r.get(s)??{from:o,to:n,latency:0,count:0};c.latency+=e.duration,c.count+=1,r.set(s,c)})});let i=Array.from(r.values()).map(e=>({...e,latency:Math.round(e.latency/e.count)})).sort((e,t)=>t.count-e.count||t.latency-e.latency);if(i.length===0)return`<div class="muted">No inferred dependencies were captured in this session.</div>`;let a=Array.from(new Set(i.flatMap(e=>[e.from,e.to]))),o=Math.min(165,62+a.length*15),s=new Map(a.map((e,t)=>{let n=t/a.length*Math.PI*2-Math.PI/2;return[e,{x:490+Math.cos(n)*o,y:223+Math.sin(n)*o}]}));return`<svg viewBox="0 0 980 430" width="100%" height="430" role="img" aria-label="Dependency map">
    <defs>
      <marker id="report-arrow" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">
        <path d="M0,0 L9,4.5 L0,9 Z" fill="#9c96a6" />
      </marker>
    </defs>
    <rect x="0" y="0" width="980" height="430" rx="8" fill="#18151d" />
    <text x="18" y="24" fill="#eee8f5" font-size="13" font-weight="800">Inferred API dependencies</text>
    <text x="18" y="41" fill="#79737f" font-size="10">Node size shows captured call frequency. Edge labels show downstream average latency.</text>
    <g transform="translate(600, 26)" font-size="10" fill="#9c96a6">
      <line x1="0" y1="0" x2="22" y2="0" stroke="#22C55E" stroke-width="2" /><text x="30" y="4">Fast</text>
      <line x1="86" y1="0" x2="108" y2="0" stroke="#F59E0B" stroke-width="2" /><text x="116" y="4">500ms+</text>
      <line x1="200" y1="0" x2="222" y2="0" stroke="#EF4444" stroke-width="2" /><text x="230" y="4">1.5s+</text>
    </g>
    ${i.map(e=>{let t=s.get(e.from),n=s.get(e.to);if(!t||!n)return``;let r=(t.x+n.x)/2,i=(t.y+n.y)/2,a=490+(r-490)*.25,o=223+(i-223)*.25;return`<g>
      <path d="M ${t.x.toFixed(1)} ${t.y.toFixed(1)} Q ${a.toFixed(1)} ${o.toFixed(1)} ${n.x.toFixed(1)} ${n.y.toFixed(1)}" fill="none" stroke="${U(e.latency)}" stroke-width="${Math.min(4,1.2+e.count*.5).toFixed(1)}" marker-end="url(#report-arrow)" opacity="0.88">
        <title>${L(`${B(e.from)} -> ${B(e.to)} - ${e.count} call chain(s), avg ${V(e.latency)}`)}</title>
      </path>
      <text x="${r.toFixed(1)}" y="${(i-5).toFixed(1)}" fill="#9c96a6" font-size="9" text-anchor="middle">${V(e.latency)}</text>
    </g>`}).join(``)}
    ${a.map(e=>{let t=s.get(e),r=n.get(e)??1,i=Math.min(20,8+r*1.5);return`<g>
      <circle cx="${t.x.toFixed(1)}" cy="${t.y.toFixed(1)}" r="${i+7}" fill="rgba(203, 184, 255, 0.07)" />
      <circle cx="${t.x.toFixed(1)}" cy="${t.y.toFixed(1)}" r="${i}" fill="#292630" stroke="#cbb8ff" stroke-width="1.5">
        <title>${L(`${e} - ${r} captured call(s)`)}</title>
      </circle>
      <circle cx="${(t.x+i-2).toFixed(1)}" cy="${(t.y-i+2).toFixed(1)}" r="8" fill="#8069bf" stroke="#121015" stroke-width="1.5" />
      <text x="${(t.x+i-2).toFixed(1)}" y="${(t.y-i+5).toFixed(1)}" fill="#eee8f5" font-size="8" font-weight="800" text-anchor="middle">${r}</text>
      <text x="${t.x.toFixed(1)}" y="${(t.y+i+16).toFixed(1)}" fill="#eee8f5" font-size="10" font-weight="700" text-anchor="middle">${L(R(B(e),26))}</text>
      <text x="${t.x.toFixed(1)}" y="${(t.y+i+29).toFixed(1)}" fill="#79737f" font-size="9" text-anchor="middle">${L(R(e,34))}</text>
    </g>`}).join(``)}
  </svg>`}function j(e){if(e==null||e===``)return``;if(typeof e==`string`)try{return JSON.stringify(JSON.parse(e),null,2)}catch{return e}return JSON.stringify(e,null,2)}function M(e,t,n,r){return typeof e==`string`&&e.trim()||e&&typeof e==`object`?j(e):t&&t.trim()?j(t):n>0?`[${r} body unavailable in capture, ${H(n)} transferred]`:`[no ${r} body captured]`}function N(e){return e===`cdp`?`CDP`:e===`performance`?`Browser`:`Proxy`}function P(e,t){return e.responseSize>t*1024}function F(e,t){return[e.isSlow?`<span class="badge danger-bg">SLOW</span>`:``,e.duplicateCount>1?`<span class="badge warn-bg">DUP x${e.duplicateCount}</span>`:``,P(e,t)?`<span class="badge warn-bg">LARGE ${L(H(e.responseSize))}</span>`:``].filter(Boolean).join(``)}function I(e,t){return[[`Source`,N(e.timingSource)],[`Duration`,V(e.duration)],[`TTFB`,e.ttfb>0?V(e.ttfb):`-`],[`DNS`,e.dnsTime>0?V(e.dnsTime):`-`],[`Connect`,e.connectTime>0?V(e.connectTime):`-`],[`SSL`,e.sslTime>0?V(e.sslTime):`-`],[`Request`,e.requestTime>0?V(e.requestTime):`-`],[`Response`,e.responseTime>0?V(e.responseTime):`-`],[`Transfer`,H(e.transferSize)],[`Decoded`,H(e.decodedBodySize)],[`Payload Limit`,H(t*1024)]].map(([e,t])=>`
    <div class="timing-cell">
      <span class="label">${L(e)}</span>
      <div class="value">${L(t)}</div>
    </div>
  `).join(``)}function L(e){return String(e).replaceAll(`&`,`&amp;`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`).replaceAll(`"`,`&quot;`).replaceAll(`'`,`&#39;`)}function R(e,t){if(e.length<=t)return e;let n=Math.max(4,Math.floor((t-3)/2));return`${e.slice(0,n)}...${e.slice(-n)}`}function z(e){try{return new URL(e).pathname}catch{return e}}function B(e){let t=e.split(`/`).filter(Boolean).slice(-2);return R(t.length>0?`/${t.join(`/`)}`:`/`,32)}function V(e){return e>999?`${(e/1e3).toFixed(1)}s`:`${e}ms`}function H(e){return e<1024?`${e} B`:e<1024*1024?`${(e/1024).toFixed(1)} KB`:`${(e/(1024*1024)).toFixed(1)} MB`}function U(e){return e<500?`#22C55E`:e<1500?`#F59E0B`:`#EF4444`}if(typeof document<`u`){let e=document.getElementById(`root`);if(e){let t=window.__apiDebuggerSidePanelRoot??(0,o.createRoot)(e);window.__apiDebuggerSidePanelRoot=t,t.render((0,s.jsx)(d,{}))}}